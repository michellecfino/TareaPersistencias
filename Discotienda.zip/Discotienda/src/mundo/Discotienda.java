package mundo;

import java.util.ArrayList;

public class Discotienda {

	private ArrayList<Disco> discos;
	
	public Discotienda() {
		discos = new ArrayList<Disco>();
	}

	public ArrayList<Disco> getDiscos() {
		return discos;
	}

	public void setDiscos(ArrayList<Disco> discos) {
		this.discos = discos;
	}
	

	
	
	
	
}
